﻿using System;

namespace MiniChatbot
{
    class Program
    {
        static void Main(string[] args)
        {
            // Afficher un message de bienvenue
            Console.WriteLine("Bienvenue sur ce mini Chatbot! Posez-moi une question, ou dites moi simplement bonjour.");

            // Boucle principale pour continuer à recevoir les messages de l'utilisateur
            while (true)
            {
                Console.Write("Vous: ");
                string userInput = Console.ReadLine().ToLower(); // Lecture et conversion en minuscule de l'entrée utilisateur

                // Réponses du chatbot en fonction de l'entrée utilisateur
                if (userInput.Contains("bonjour") || userInput.Contains("salut"))
                {
                    Console.WriteLine("Chatbot: Bonjour! Comment puis-je vous aider ?");
                }
                else if (userInput.Contains("bonsoir"))
                {
                    Console.WriteLine("Chatbot: Bonsoir! Comment puis-je vous aider ?");
                }
                else if (userInput.Contains("comment ça va") || userInput.Contains("ça va"))
                {
                    Console.WriteLine("Chatbot: Je vais très bien! Et vous?");
                }
                else if (userInput.Contains("quel est ton nom") || userInput.Contains("comment tu t'appelles"))
                {
                    Console.WriteLine("Chatbot: Je suis le MiniChatbot, enchanté de faire votre connaissance!");
                }
                else if (userInput.Contains("quelle heure est-il") || userInput.Contains("heure"))
                {
                    Console.WriteLine($"Chatbot: Il est {DateTime.Now.ToShortTimeString()}.");
                }
                else if (userInput.Contains("quel jour sommes-nous") || userInput.Contains("date"))
                {
                    Console.WriteLine($"Chatbot: Aujourd'hui, c'est le {DateTime.Now.ToLongDateString()}.");
                }
                else if (userInput.Contains("merci"))
                {
                    Console.WriteLine("Chatbot: De rien! Si vous avez d'autres questions, n'hésitez pas.");
                }
                else if (userInput.Contains("au revoir"))
                {
                    Console.WriteLine("Chatbot: Au revoir! Passez une bonne journée.");
                    break; // Quitte la boucle et ferme le programme
                }
                else
                {
                    // Réponse par défaut si la question n'est pas reconnue
                    Console.WriteLine("Chatbot: Désolé, je ne comprends pas cette question.");
                }
            }
        }
    }
}