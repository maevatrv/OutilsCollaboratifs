<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'chess_bdd' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'fk$.6d :sLoaNB$*6Z0D>U#JtWenR2oS8K<BRZSSKTAsm|y+4Ny;>mHBWo8,3NE9' );
define( 'SECURE_AUTH_KEY',  'zd7i/ifuj1F4 }YZ?Dl8VAqL%c?zGvLlsCtC>M{SY]w|.[Dh!zk^{nd.s<a)8C62' );
define( 'LOGGED_IN_KEY',    'tmzl(>vH%fA!li)BKgzgD(w&]%`EPGKi@WMy a;C~7*>C!9[f2qJb}SYMrlF<5g5' );
define( 'NONCE_KEY',        'zY.hl`^Q*5eW &,BPB)|1T)4DP?^(h/>$-FA9)noTnu@=eIi^0sYO=KAsP.+9}:h' );
define( 'AUTH_SALT',        '.w%k8*h0@MR.+?0{%]u[qr*aeB)nUXsXkc/ qp3mvYD5C560.Tl$!|Q+0G/P34(K' );
define( 'SECURE_AUTH_SALT', 'D^1ih`iffD,Uk<F@tl|Ebvfy2.4Sgl#n*4#iQ2*OL`+v9JtOX1>(@{l(rBIPpxx|' );
define( 'LOGGED_IN_SALT',   ',u:|ZB,Lc$`YPOgIMFxr0.21jtIS]#;)^)2&P~MQ2c:/5rF6IDsCzlDo]z0Eb>mr' );
define( 'NONCE_SALT',       'm8Qai9Zd?NQEU@a|NtcpzQJ;> lh*^:Asx/rH*>24a0xBt)Sfcx^p^~KJZ9CuF?S' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://developer.wordpress.org/advanced-administration/debug/debug-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
